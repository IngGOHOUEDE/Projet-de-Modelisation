%Lionel C�dric  GOHOUEDE

v_data = zeros(1,63*365); % intialisation du vecteur ligne contenant toutes des donn�es de pr�cipitations
data_precip=table2array(PluiejournaliereCotonou);% Extraction des donn�es excel
for i =1:58
  for j = 1:365 
    v_data(j+(i-1)*365)=data_precip(j,i); % Remplissage du vecteur
  end
end
v_data_b=zeros(1,21170);
for i=1:21170
    if v_data(i)>= 0.1
        v_data_b(i)=1;     % Vecteur comportant 0 pour absence pr�cipiation ou 1 pour pr�sence de pr�cipitation 
    end
end
z=0;o=0;
for i=1:21170
    if v_data_b(i)==0;
        z=z+1;
    elseif v_data_b(i)==1
        o=o+1; 
    end
end
zero_zero=[0,0];zero_one=[0,1];one_zero=[1,0];one_one=[1,1]; % Calcul de N00=zz, N01=zo, N10=10 et N11=oo
zz=0;zo=0;oz=0;oo=0;
for i=1:21169
    if v_data_b(i:i+1)== zero_zero;
        zz=zz+1;
    elseif v_data_b(i:i+1)==zero_one;
        zo=zo+1; 
    elseif v_data_b(i:i+1)==one_zero;
        oz=oz+1;
    elseif  v_data_b(i:i+1)==one_one;
        oo=oo+1;
    end
end
zzz=0; zzo=0;zoz=0;zoo=0;ozz=0; ozo=0;ooz=0;ooo=0;% Calcul de N000, N001,..., N111
for i=1:21168
    if v_data_b(i:i+2)== [0,0,0];
        zzz=zzz+1;
    elseif v_data_b(i:i+2)==[0,0,1];
        zzo=zzo+1; 
    elseif v_data_b(i:i+2)==[0,1,0];
        zoz=zoz+1;
    elseif  v_data_b(i:i+2)==[0,1,1];
        zoo=zoo+1;
    elseif v_data_b(i:i+2)== [1,0,0];
        ozz=ozz+1;
    elseif v_data_b(i:i+2)==[1,0,1];
        ozo=ozo+1; 
    elseif v_data_b(i:i+2)==[1,1,0];
        ooz=ooz+1;
    elseif  v_data_b(i:i+2)==[1,1,1];
        ooo=ooo+1;
    end
end
pzz=zz/z; poz=oz/o;pzzz=zzz/zz;pzoz=zoz/zo;pozz=ozz/oz;pooz=ooz/oo;
%---------validation-----------------------------------------------------------------------------
tab_v=zeros(1,5*365);
for i =1:5
  for j = 1:365 
    tab_v(j+(i-1)*365)=data_precip(j,i+58);% remplissage du vecteur tab_v avec les donn�es de validation
  end
end
tab_b=zeros(1,1825);
for i=1:1825
    if tab_v(i)>= 0.1
        tab_b(i)=1;
    end
end
zv=0;ov=0;% N0 et N1 pour la validation
for i=1:1825
    if tab_b(i)==0;
        zv=zv+1;
    elseif tab_b(i)==1
        ov=ov+1; 
    end
end

