x=0:1:22932;
y=ones(1,22933);
hold on
plot(v_data,'k'),title('pr�cipitations journali�res de 1952 � 2014');
plot(x,y,'r');
legend('pr�cipitations','seuil de 1mm');
hold off
